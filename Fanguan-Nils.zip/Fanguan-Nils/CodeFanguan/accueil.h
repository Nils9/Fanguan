//Arthur
#ifndef ACCUEIL_H
#define ACCUEIL_H

#include <QWidget>

class Accueil : public QWidget
{
    Q_OBJECT
public:
    explicit Accueil(QWidget *parent = nullptr);

signals:

public slots:

};

#endif // ACCUEIL_H
