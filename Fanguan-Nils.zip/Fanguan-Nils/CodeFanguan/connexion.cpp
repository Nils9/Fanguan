#include "connexion.h"

Connexion::Connexion(QWidget *parent) : QWidget(parent)
{

}
