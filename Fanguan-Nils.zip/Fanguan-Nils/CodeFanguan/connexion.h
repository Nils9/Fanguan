//Julien
#ifndef CONNEXION_H
#define CONNEXION_H

#include <QWidget>

class Connexion : public QWidget
{
    Q_OBJECT
public:
    explicit Connexion(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // CONNEXION_H
