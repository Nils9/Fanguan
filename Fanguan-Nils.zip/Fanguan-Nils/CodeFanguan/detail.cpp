#include "detail.h"

Detail::Detail(QWidget *parent) : QWidget(parent)
{

}

