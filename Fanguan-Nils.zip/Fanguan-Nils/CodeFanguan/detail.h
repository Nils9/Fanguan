//Arthur
#ifndef DETAIL_H
#define DETAIL_H

#include <QWidget>

class Detail : public QWidget
{
    Q_OBJECT
public:
    explicit Detail(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // DETAIL_H
