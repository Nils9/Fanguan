#include "espaceabo.h"

EspaceAbo::EspaceAbo(QWidget *parent) : QWidget(parent)
{

}
