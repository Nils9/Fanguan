//Arthur
#ifndef DETAIL_H
#define DETAIL_H

#include <QWidget>

class EspaceAbo : public QWidget
{
    Q_OBJECT
public:
    explicit EspaceAbo(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // DETAIL_H
