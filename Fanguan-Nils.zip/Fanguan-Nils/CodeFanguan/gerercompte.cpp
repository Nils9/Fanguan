#include "gerercompte.h"

GererCompte::GererCompte(QWidget *parent) : QWidget(parent)
{

}
