//Gérer Compte
#ifndef GERERCOMPTE_H
#define GERERCOMPTE_H

#include <QWidget>

class GererCompte : public QWidget
{
    Q_OBJECT
public:
    explicit GererCompte(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // GERERCOMPTE_H
