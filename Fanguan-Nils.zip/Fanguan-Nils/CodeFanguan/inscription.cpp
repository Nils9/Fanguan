#include "inscription.h"

Inscription::Inscription(QWidget *parent) : QWidget(parent)
{

}
