//Julien
#ifndef INSCRIPTION_H
#define INSCRIPTION_H

#include <QWidget>

class Inscription : public QWidget
{
    Q_OBJECT
public:
    explicit Inscription(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // INSCRIPTION_H
