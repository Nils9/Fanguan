#include "menu.h"

Menu::Menu(QWidget *parent) : QWidget(parent)
{

}

