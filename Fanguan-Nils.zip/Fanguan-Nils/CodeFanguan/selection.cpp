#include "selection.h"

Selection::Selection(QWidget *parent) : QWidget(parent)
{

}
