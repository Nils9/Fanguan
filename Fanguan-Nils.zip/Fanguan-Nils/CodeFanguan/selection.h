//Plus tard
#ifndef SELECTION_H
#define SELECTION_H

#include <QWidget>

class Selection : public QWidget
{
    Q_OBJECT
public:
    explicit Selection(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // SELECTION_H
